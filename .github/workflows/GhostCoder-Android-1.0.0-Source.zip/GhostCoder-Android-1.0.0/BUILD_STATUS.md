# Build status

The source overlay is complete and wired to the official llama.cpp Android JNI interface.

This ChatGPT execution environment contains Java 21 but does not contain an Android SDK,
Android NDK, Gradle installation, or cached Android dependencies, so an APK cannot be
compiled and validated locally in this environment.

Use the included GitHub Actions workflow or Android Studio/SDK to compile it.

Before distributing a release APK:
1. Build and install a debug APK on a real ARM64 Android phone.
2. Test the 1.5B model first.
3. Test 7B only on a phone with sufficient memory.
4. Verify model download completion and app-private storage behavior.
5. Add a permanent release signing key and keep it outside source control.
6. Add workspace/file tools only after enforcing scoped-storage permissions.
