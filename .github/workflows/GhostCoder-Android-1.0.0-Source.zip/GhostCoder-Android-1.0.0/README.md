# GhostCoder Android 1.0.0

A local-first Android coding-agent project combining:

- Ghost in the Droid's Android "body" concepts (Accessibility-controlled phone tools)
- llama.cpp's official Android JNI inference library
- Qwen2.5-Coder-1.5B-Instruct-GGUF Q4_K_M (light profile)
- Qwen2.5-Coder-7B-Instruct-GGUF Q4_K_M (quality profile)

The model weights are **not** bundled in the APK. The app downloads or imports a GGUF model
after installation. This keeps the APK reasonably sized and lets the user choose the model
that fits the phone.

## Intended package

`com.ghostcoder.local`

## Local-only design

After a model has been downloaded/imported, inference runs through llama.cpp on the Android
device. No OpenAI/Anthropic/cloud key is required.

## Model profiles

### Light
- Qwen/Qwen2.5-Coder-1.5B-Instruct-GGUF
- Q4_K_M
- Default profile
- Better fit for phones with limited memory

### Higher quality
- Qwen/Qwen2.5-Coder-7B-Instruct-GGUF
- Q4_K_M
- Intended for high-memory phones
- The app warns before selecting this profile

## Build architecture

This repository is an **overlay build**. The GitHub Actions workflow:

1. Clones a pinned llama.cpp revision.
2. Uses llama.cpp's official `examples/llama.android` Android project and JNI library.
3. Replaces the demo app with the GhostCoder app overlay.
4. Adds Ghost-style Accessibility control.
5. Builds a debug APK and uploads it as an Actions artifact.

This approach avoids copying the entire fast-moving llama.cpp source tree into this bundle.

## Build locally

Requirements:
- Android Studio / Android SDK 36
- Android NDK compatible with the pinned llama.cpp Android project
- JDK 17
- Git

Run:

```bash
bash scripts/prepare.sh
cd build-src/examples/llama.android
./gradlew :app:assembleDebug
```

APK:

`build-src/examples/llama.android/app/build/outputs/apk/debug/app-debug.apk`

## Build with GitHub Actions

Push this folder to a GitHub repository. The included workflow `build-apk.yml` performs the
build and uploads `GhostCoder-Android-debug.apk` as a workflow artifact.

## Important implementation note

Ghost's public README describes on-device Android llama.cpp support, but the public Portal
source currently exposes the Android control/Accessibility components while the advertised
on-device inference JNI implementation is not present in that Portal tree. This project
therefore uses Ghost for the Android-agent/control design and llama.cpp's *official* Android
JNI binding for the local inference layer.

## Agent behavior

The local system prompt tells Qwen to operate as a software-development agent. The app's
initial tool surface is intentionally conservative:

- inspect the current Android screen through Accessibility
- tap by screen coordinates
- enter text
- press Back/Home
- maintain local conversation state

A production iteration can add a Storage Access Framework workspace, patch/diff tools,
project ZIP import/export, local Git, and an isolated build runner.

## Licenses

See `licenses/NOTICE.md`.

This project does not redistribute the Qwen GGUF weights. Downloading a model is a separate
user action.
