# Third-party notices

## Ghost in the Droid
Upstream: https://github.com/ghost-in-the-droid/android-agent
License: MIT
This project follows Ghost's Android agent / accessibility-control architecture and includes
an adapted minimal Accessibility service implementation.

## llama.cpp
Upstream: https://github.com/ggml-org/llama.cpp
License: MIT
The build workflow pins llama.cpp and uses its official `examples/llama.android` JNI library.

## Qwen2.5-Coder
Models:
- Qwen/Qwen2.5-Coder-1.5B-Instruct-GGUF
- Qwen/Qwen2.5-Coder-7B-Instruct-GGUF
License displayed by the official Hugging Face model repositories: Apache-2.0.

Model weights are not redistributed in this source bundle or APK.
