package com.ghostcoder.local

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.*

class MainActivity : AppCompatActivity() {
    private lateinit var modelManager: ModelManager
    private lateinit var agent: LocalCodingAgent

    private lateinit var modelSpinner: Spinner
    private lateinit var status: TextView
    private lateinit var transcript: TextView
    private lateinit var prompt: EditText
    private lateinit var send: Button
    private lateinit var download: Button

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        modelManager = ModelManager(this)
        agent = LocalCodingAgent(this)
        setContentView(buildUi())
        wireUi()
        refreshStatus()
    }

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 24)
        }

        root.addView(TextView(this).apply {
            text = "GhostCoder"
            textSize = 28f
        })
        root.addView(TextView(this).apply {
            text = "Local, offline coding agent • Ghost-style Android tools • llama.cpp"
            textSize = 14f
        })

        modelSpinner = Spinner(this)
        modelSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            ModelCatalog.all.map { it.title }
        )
        root.addView(modelSpinner)

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        download = Button(this).apply { text = "Download model" }
        val accessibility = Button(this).apply {
            text = "Agent tools"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        actions.addView(download, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        actions.addView(accessibility, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(actions)

        status = TextView(this).apply { setPadding(0, 8, 0, 8) }
        root.addView(status)

        val scroll = ScrollView(this)
        transcript = TextView(this).apply {
            text = "Select/download a model, then ask for code, debugging, architecture, or software help.\n\n"
            textSize = 15f
            setTextIsSelectable(true)
        }
        scroll.addView(transcript)
        root.addView(scroll, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        prompt = EditText(this).apply {
            hint = "Ask GhostCoder…"
            minLines = 2
            maxLines = 6
            gravity = Gravity.TOP
        }
        root.addView(prompt)

        send = Button(this).apply { text = "Run locally" }
        root.addView(send)
        return root
    }

    private fun wireUi() {
        val selectedIndex = ModelCatalog.all.indexOf(modelManager.selected()).coerceAtLeast(0)
        modelSpinner.setSelection(selectedIndex)

        modelSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                val p = ModelCatalog.all[position]
                if (p == ModelCatalog.QUALITY && modelManager.selected() != p) {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("7B model")
                        .setMessage("The 7B Q4_K_M model needs substantially more storage and RAM. On phones without enough free memory Android may terminate the app during model loading.")
                        .setPositiveButton("Use 7B") { _, _ -> modelManager.select(p); refreshStatus() }
                        .setNegativeButton("Keep light model") { _, _ ->
                            modelSpinner.setSelection(ModelCatalog.all.indexOf(modelManager.selected()))
                        }.show()
                } else {
                    modelManager.select(p)
                    refreshStatus()
                }
            }
        }

        download.setOnClickListener {
            val p = modelManager.selected()
            if (modelManager.isInstalled(p)) {
                Toast.makeText(this, "Model already downloaded.", Toast.LENGTH_SHORT).show()
            } else {
                modelManager.download(p)
                Toast.makeText(this, "Download started. Keep the app installed until it finishes.", Toast.LENGTH_LONG).show()
            }
        }

        send.setOnClickListener {
            val text = prompt.text.toString().trim()
            if (text.isEmpty()) return@setOnClickListener
            val p = modelManager.selected()
            val file = modelManager.modelFile(p)
            if (!file.exists()) {
                Toast.makeText(this, "Download the selected model first.", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }

            send.isEnabled = false
            transcript.append("You: $text\n\nGhostCoder: ")
            prompt.setText("")

            scope.launch {
                try {
                    withContext(Dispatchers.IO) { agent.ensureLoaded(file.absolutePath) }
                    agent.chat(text).collect { token ->
                        transcript.append(token)
                    }
                    transcript.append("\n\n")
                } catch (t: Throwable) {
                    transcript.append("\n[Error: ${t.message ?: t.javaClass.simpleName}]\n\n")
                } finally {
                    send.isEnabled = true
                    refreshStatus()
                }
            }
        }
    }

    private fun refreshStatus() {
        val p = modelManager.selected()
        status.text = if (modelManager.isInstalled(p)) {
            "Ready: ${p.title}"
        } else {
            "Not installed: ${p.title}\n${p.qualityNote}"
        }
    }

    override fun onDestroy() {
        scope.cancel()
        agent.unload()
        super.onDestroy()
    }
}
