package com.ghostcoder.local

data class ModelProfile(
    val id: String,
    val title: String,
    val repo: String,
    val fileName: String,
    val downloadUrl: String,
    val qualityNote: String
)

object ModelCatalog {
    val LIGHT = ModelProfile(
        id = "qwen25-coder-1_5b-q4km",
        title = "Qwen2.5-Coder 1.5B — Light",
        repo = "Qwen/Qwen2.5-Coder-1.5B-Instruct-GGUF",
        fileName = "qwen2.5-coder-1.5b-instruct-q4_k_m.gguf",
        downloadUrl = "https://huggingface.co/Qwen/Qwen2.5-Coder-1.5B-Instruct-GGUF/resolve/main/qwen2.5-coder-1.5b-instruct-q4_k_m.gguf",
        qualityNote = "Default. Lower memory and faster startup."
    )

    val QUALITY = ModelProfile(
        id = "qwen25-coder-7b-q4km",
        title = "Qwen2.5-Coder 7B — Higher Quality",
        repo = "Qwen/Qwen2.5-Coder-7B-Instruct-GGUF",
        fileName = "qwen2.5-coder-7b-instruct-q4_k_m.gguf",
        downloadUrl = "https://huggingface.co/Qwen/Qwen2.5-Coder-7B-Instruct-GGUF/resolve/main/qwen2.5-coder-7b-instruct-q4_k_m.gguf",
        qualityNote = "Higher-quality coding model. Requires substantially more free RAM/storage."
    )

    val all = listOf(LIGHT, QUALITY)
}
