package com.ghostcoder.local

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import java.io.File

class ModelManager(private val context: Context) {
    private val prefs = context.getSharedPreferences("ghostcoder", Context.MODE_PRIVATE)

    fun modelFile(profile: ModelProfile): File =
        File(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), profile.fileName)

    fun isInstalled(profile: ModelProfile): Boolean = modelFile(profile).let { it.exists() && it.length() > 0 }

    fun selected(): ModelProfile {
        val id = prefs.getString("selected_model", ModelCatalog.LIGHT.id)
        return ModelCatalog.all.firstOrNull { it.id == id } ?: ModelCatalog.LIGHT
    }

    fun select(profile: ModelProfile) {
        prefs.edit().putString("selected_model", profile.id).apply()
    }

    fun download(profile: ModelProfile): Long {
        val request = DownloadManager.Request(Uri.parse(profile.downloadUrl))
            .setTitle(profile.title)
            .setDescription("Downloading local GGUF model")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setAllowedOverMetered(false)
            .setDestinationUri(Uri.fromFile(modelFile(profile)))

        val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        return dm.enqueue(request)
    }
}
