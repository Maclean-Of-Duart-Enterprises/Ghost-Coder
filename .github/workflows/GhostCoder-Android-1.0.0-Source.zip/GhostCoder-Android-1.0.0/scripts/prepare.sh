#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SRC="$ROOT/build-src"
LLAMA_COMMIT="34af94cd9ab277632e27caeec2d41de2fd091b31"

rm -rf "$SRC"
git clone https://github.com/ggml-org/llama.cpp.git "$SRC"
cd "$SRC"
git checkout "$LLAMA_COMMIT"

APP="$SRC/examples/llama.android/app"
rm -rf "$APP/src"
cp -a "$ROOT/overlay/app/src" "$APP/src"
cp "$ROOT/overlay/app/build.gradle.kts" "$APP/build.gradle.kts"
cp "$ROOT/overlay/app/proguard-rules.pro" "$APP/proguard-rules.pro"

echo "Prepared source at: $SRC/examples/llama.android"
echo "Build with:"
echo "  cd \"$SRC/examples/llama.android\" && ./gradlew :app:assembleDebug"
